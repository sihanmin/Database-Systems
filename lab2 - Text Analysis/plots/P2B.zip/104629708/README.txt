Extra credit:
1.summarize the number of comments at certain date, because at certain date, people are more active in posting their comments. For example, during the election period people might be more actively posting their comments about Trump.
